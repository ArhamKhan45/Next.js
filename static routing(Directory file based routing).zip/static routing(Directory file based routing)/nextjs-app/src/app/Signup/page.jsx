function SignupPage() {
  return (
    <div>
      <h1>sign-up page</h1>
    </div>
  );
}

export default SignupPage;
