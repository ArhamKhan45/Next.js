function loginpage() {
  return (
    <div>
      <h1>Login page</h1>
    </div>
  );
}

export default loginpage;
