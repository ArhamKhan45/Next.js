function successpage() {
  return (
    <div>
      <h1>success</h1>
    </div>
  );
}

export default successpage;
