import styles from "./page.css";

export default function Home() {
  return (
    <main className={styles.main}>
      <h1>Arham khan</h1>
    </main>
  );
}
